'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Navigation } from '@/components/layout/Navigation'
import { Dashboard } from '@/components/sections/Dashboard'
import { StudentProfile } from '@/components/sections/StudentProfile'
import { SkillAssessment } from '@/components/sections/SkillAssessment'
import { SkillGapAnalysis } from '@/components/sections/SkillGapAnalysis'
import { LearningRoadmap } from '@/components/sections/LearningRoadmap'
import { CourseRecommendations } from '@/components/sections/CourseRecommendations'
import { ProgressTracking } from '@/components/sections/ProgressTracking'
import { AIChatAssistant } from '@/components/sections/AIChatAssistant'
import { CareerGuidance } from '@/components/sections/CareerGuidance'
import { Settings } from '@/components/sections/Settings'

interface UserData {
  email: string
  name: string
  password: string
}

interface DashboardPageProps {
  currentPage: string
  setCurrentPage: (page: string) => void
  userData: UserData
}

export function DashboardPage({ currentPage, setCurrentPage, userData }: DashboardPageProps) {
  const renderPage = () => {
    switch (currentPage) {
      case 'profile':
        return <StudentProfile userData={userData} />
      case 'assessment':
        return <SkillAssessment />
      case 'skill-gap':
        return <SkillGapAnalysis />
      case 'roadmap':
        return <LearningRoadmap />
      case 'courses':
        return <CourseRecommendations />
      case 'progress':
        return <ProgressTracking />
      case 'chat':
        return <AIChatAssistant />
      case 'career':
        return <CareerGuidance />
      case 'settings':
        return <Settings />
      default:
        return <Dashboard setCurrentPage={setCurrentPage} userData={userData} />
    }
  }

  return (
    <div className="min-h-screen bg-background flex">
      <Navigation currentPage={currentPage} setCurrentPage={setCurrentPage} />
      
      <main className="flex-1 overflow-auto">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPage}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
            className="p-4 md:p-8"
          >
            {renderPage()}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  )
}
