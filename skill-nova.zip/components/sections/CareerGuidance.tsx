'use client'

import { motion } from 'framer-motion'
import { Briefcase, MapPin, DollarSign, TrendingUp, Users, Target } from 'lucide-react'

export function CareerGuidance() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  }

  const careerPaths = [
    {
      title: 'Full-Stack Engineer',
      salary: '$150K - $250K',
      demand: 'Very High',
      skills: ['React', 'Node.js', 'Cloud', 'DevOps'],
      match: 92,
      color: 'from-primary',
    },
    {
      title: 'Backend Architect',
      salary: '$160K - $280K',
      demand: 'High',
      skills: ['System Design', 'Databases', 'Cloud', 'Scalability'],
      match: 88,
      color: 'from-secondary',
    },
    {
      title: 'ML Engineer',
      salary: '$170K - $300K',
      demand: 'Very High',
      skills: ['Python', 'TensorFlow', 'MLOps', 'Statistics'],
      match: 75,
      color: 'from-accent',
    },
    {
      title: 'DevOps Engineer',
      salary: '$140K - $220K',
      demand: 'High',
      skills: ['Kubernetes', 'Docker', 'CI/CD', 'Infrastructure'],
      match: 82,
      color: 'from-teal-500',
    },
  ]

  const companies = [
    { name: 'Google', icon: '🔍', hires: '500+/year', salary: '$200K+' },
    { name: 'Microsoft', icon: '💻', hires: '400+/year', salary: '$190K+' },
    { name: 'Amazon', icon: '📦', hires: '600+/year', salary: '$210K+' },
    { name: 'Meta', icon: '👥', hires: '300+/year', salary: '$220K+' },
    { name: 'Apple', icon: '🍎', hires: '250+/year', salary: '$200K+' },
    { name: 'Netflix', icon: '🎬', hires: '150+/year', salary: '$240K+' },
  ]

  return (
    <motion.div
      className="max-w-6xl mx-auto space-y-6"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      <motion.div variants={itemVariants}>
        <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary mb-2">
          Career Guidance
        </h1>
        <p className="text-muted-foreground">
          Explore career paths and get recommendations based on your skills
        </p>
      </motion.div>

      {/* Career Paths */}
      <motion.div
        className="premium-card"
        variants={itemVariants}
      >
        <h2 className="text-2xl font-bold text-foreground mb-6">Recommended Career Paths</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {careerPaths.map((path, idx) => (
            <motion.div
              key={idx}
              className={`p-6 rounded-2xl border border-white/10 bg-gradient-to-br ${path.color}/10 hover:border-white/30 smooth-transition cursor-pointer`}
              variants={itemVariants}
              whileHover={{ y: -4 }}
            >
              <div className="flex items-start justify-between mb-4">
                <h3 className="text-lg font-bold text-foreground">{path.title}</h3>
                <motion.div
                  className="text-right"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                >
                  <div className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">
                    {path.match}%
                  </div>
                  <p className="text-xs text-muted-foreground">Match</p>
                </motion.div>
              </div>

              <div className="space-y-3 mb-4">
                <div className="flex items-center gap-2 text-sm">
                  <DollarSign className="w-4 h-4 text-accent" />
                  <span className="text-foreground font-semibold">{path.salary}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <TrendingUp className="w-4 h-4 text-primary" />
                  <span className="text-foreground font-semibold">{path.demand}</span>
                </div>
              </div>

              <div className="space-y-2">
                <p className="text-xs text-muted-foreground font-semibold uppercase">
                  Key Skills Required
                </p>
                <div className="flex flex-wrap gap-2">
                  {path.skills.map((skill) => (
                    <span
                      key={skill}
                      className={`px-3 py-1 rounded-full text-xs font-medium bg-gradient-to-r ${path.color} text-white`}
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              <motion.button
                className="w-full mt-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 smooth-transition font-semibold text-sm"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                Explore Path
              </motion.button>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Top Companies */}
      <motion.div
        className="premium-card"
        variants={itemVariants}
      >
        <div className="flex items-center gap-3 mb-6">
          <Users className="w-6 h-6 text-primary" />
          <h2 className="text-2xl font-bold text-foreground">Top Hiring Companies</h2>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {companies.map((company, idx) => (
            <motion.div
              key={idx}
              className="p-4 rounded-xl border border-white/10 bg-white/5 hover:border-primary/50 smooth-transition text-center"
              variants={itemVariants}
              whileHover={{ y: -4 }}
            >
              <p className="text-3xl mb-2">{company.icon}</p>
              <p className="font-bold text-foreground mb-1">{company.name}</p>
              <p className="text-xs text-muted-foreground mb-2">{company.hires}</p>
              <p className="text-sm font-semibold text-accent">{company.salary}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Interview Prep */}
      <motion.div
        className="premium-card gradient-teal-violet"
        variants={itemVariants}
      >
        <div className="flex items-center gap-3 mb-6">
          <Target className="w-6 h-6 text-accent" />
          <h2 className="text-2xl font-bold text-foreground">Interview Preparation</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            {
              title: 'Behavioral Interviews',
              topics: ['Leadership', 'Teamwork', 'Problem-solving', 'Conflict resolution'],
            },
            {
              title: 'Technical Interviews',
              topics: ['Algorithms', 'System Design', 'Coding', 'Data Structures'],
            },
            {
              title: 'Salary Negotiation',
              topics: ['Market research', 'Negotiation tactics', 'Benefits', 'Equity'],
            },
            {
              title: 'Company Research',
              topics: ['Culture fit', 'Growth opportunities', 'Tech stack', 'Values'],
            },
          ].map((category, idx) => (
            <motion.div
              key={idx}
              className="p-4 rounded-lg border border-white/20 bg-white/5"
              whileHover={{ borderColor: 'rgba(255, 255, 255, 0.3)' }}
            >
              <h3 className="font-bold text-foreground mb-3">{category.title}</h3>
              <div className="space-y-2">
                {category.topics.map((topic) => (
                  <motion.div
                    key={topic}
                    className="flex items-center gap-2 text-sm text-muted-foreground"
                    whileHover={{ x: 4 }}
                  >
                    <span className="w-2 h-2 rounded-full bg-primary" />
                    {topic}
                  </motion.div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Career Timeline */}
      <motion.div
        className="premium-card"
        variants={itemVariants}
      >
        <h2 className="text-2xl font-bold text-foreground mb-6">Your Career Timeline</h2>
        <div className="space-y-4">
          {[
            {
              milestone: 'Complete Fundamentals',
              timeline: '3 months',
              status: 'in-progress',
              description: 'Master core programming concepts and problem-solving',
            },
            {
              milestone: 'Build Portfolio Projects',
              timeline: '2 months',
              status: 'pending',
              description: 'Create 3-4 impressive full-stack projects',
            },
            {
              milestone: 'Interview Preparation',
              timeline: '2 months',
              status: 'pending',
              description: 'Practice coding and behavioral interviews',
            },
            {
              milestone: 'Start Applying',
              timeline: 'Ongoing',
              status: 'pending',
              description: 'Apply to target companies and positions',
            },
          ].map((milestone, idx) => (
            <motion.div
              key={idx}
              className={`p-4 rounded-lg border-l-4 ${
                milestone.status === 'in-progress'
                  ? 'border-l-primary bg-primary/10'
                  : 'border-l-muted-foreground bg-white/5'
              }`}
              whileHover={{ x: 4 }}
            >
              <div className="flex items-start justify-between mb-2">
                <h3 className="font-bold text-foreground">{milestone.milestone}</h3>
                <span className={`text-xs px-2 py-1 rounded-full font-bold ${
                  milestone.status === 'in-progress'
                    ? 'bg-primary/30 text-primary'
                    : 'bg-white/10 text-muted-foreground'
                }`}>
                  {milestone.timeline}
                </span>
              </div>
              <p className="text-sm text-muted-foreground">{milestone.description}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </motion.div>
  )
}
