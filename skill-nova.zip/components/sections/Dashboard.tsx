'use client'

import { motion } from 'framer-motion'
import {
  TrendingUp,
  BookOpen,
  Target,
  Zap,
  Clock,
  Award,
  ArrowRight,
} from 'lucide-react'

interface UserData {
  email: string
  name: string
  password: string
}

interface DashboardProps {
  setCurrentPage: (page: string) => void
  userData?: UserData
}

export function Dashboard({ setCurrentPage, userData }: DashboardProps) {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  }

  return (
    <motion.div
      className="space-y-6 max-w-7xl mx-auto"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      {/* Header */}
      <motion.div variants={itemVariants}>
        <h1 className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary via-secondary to-accent mb-2">
          Welcome back, {userData?.name}! 👋
        </h1>
        <p className="text-muted-foreground text-lg">
          Email: <span className="text-primary font-semibold">{userData?.email}</span>
        </p>
        <p className="text-muted-foreground text-lg">
          Let&apos;s continue your learning journey with AI-powered insights
        </p>
      </motion.div>

      {/* Quick Stats */}
      <motion.div
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4"
        variants={containerVariants}
      >
        {[
          {
            icon: Award,
            label: 'Current Streak',
            value: '15 days',
            color: 'from-primary to-teal-500',
          },
          {
            icon: BookOpen,
            label: 'Courses Active',
            value: '8',
            color: 'from-secondary to-violet-600',
          },
          {
            icon: TrendingUp,
            label: 'Skill Progress',
            value: '72%',
            color: 'from-accent to-amber-500',
          },
          {
            icon: Clock,
            label: 'Learning Hours',
            value: '156 hrs',
            color: 'from-cyan-500 to-cyan-400',
          },
        ].map((stat, idx) => {
          const Icon = stat.icon
          return (
            <motion.div
              key={idx}
              className="premium-card"
              variants={itemVariants}
              whileHover={{ y: -4 }}
            >
              <div className={`inline-block p-3 bg-gradient-to-br ${stat.color} rounded-lg mb-4`}>
                <Icon className="w-6 h-6 text-white" />
              </div>
              <p className="text-muted-foreground text-sm mb-1">{stat.label}</p>
              <p className="text-2xl font-bold text-foreground">{stat.value}</p>
            </motion.div>
          )
        })}
      </motion.div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column */}
        <div className="lg:col-span-2 space-y-6">
          {/* Recommended Courses */}
          <motion.div
            className="premium-card"
            variants={itemVariants}
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-foreground">Recommended For You</h2>
              <motion.button
                onClick={() => setCurrentPage('courses')}
                className="text-primary hover:text-primary/80 font-semibold flex items-center gap-2 smooth-transition"
                whileHover={{ x: 4 }}
              >
                View All <ArrowRight className="w-4 h-4" />
              </motion.button>
            </div>

            <div className="space-y-3">
              {[
                {
                  title: 'Advanced Python Programming',
                  difficulty: 'Advanced',
                  progress: 65,
                  students: 12400,
                  rating: 4.8,
                },
                {
                  title: 'Machine Learning Fundamentals',
                  difficulty: 'Intermediate',
                  progress: 42,
                  students: 8900,
                  rating: 4.9,
                },
                {
                  title: 'Web Development with Next.js',
                  difficulty: 'Intermediate',
                  progress: 28,
                  students: 15600,
                  rating: 4.7,
                },
              ].map((course, idx) => (
                <motion.div
                  key={idx}
                  className="p-4 rounded-xl bg-white/5 border border-white/10 hover:border-primary/50 smooth-transition cursor-pointer group"
                  whileHover={{ x: 4 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <h3 className="font-semibold text-foreground group-hover:text-primary smooth-transition">
                        {course.title}
                      </h3>
                      <p className="text-xs text-muted-foreground mt-1">
                        {course.difficulty} • {course.students.toLocaleString()} students • ⭐ {course.rating}
                      </p>
                    </div>
                  </div>
                  <div className="w-full bg-white/5 rounded-full h-2">
                    <motion.div
                      className="bg-gradient-to-r from-primary to-secondary h-full rounded-full"
                      initial={{ width: 0 }}
                      animate={{ width: `${course.progress}%` }}
                      transition={{ duration: 1, delay: idx * 0.1 }}
                    />
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">{course.progress}% completed</p>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Skills Overview */}
          <motion.div
            className="premium-card"
            variants={itemVariants}
          >
            <h2 className="text-2xl font-bold text-foreground mb-6">Your Top Skills</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {[
                { name: 'Python', level: 'Expert', color: 'from-blue-500 to-blue-600' },
                { name: 'React', level: 'Advanced', color: 'from-cyan-400 to-cyan-500' },
                { name: 'UI/UX Design', level: 'Intermediate', color: 'from-pink-500 to-rose-500' },
                { name: 'Data Science', level: 'Advanced', color: 'from-purple-500 to-violet-600' },
                { name: 'TypeScript', level: 'Intermediate', color: 'from-blue-400 to-blue-500' },
                { name: 'Problem Solving', level: 'Expert', color: 'from-green-500 to-emerald-600' },
              ].map((skill, idx) => (
                <motion.div
                  key={idx}
                  className="p-4 rounded-xl bg-gradient-to-br from-white/8 to-white/3 border border-white/10 hover:border-white/20 smooth-transition"
                  whileHover={{ scale: 1.05 }}
                >
                  <div className={`w-full h-2 rounded-full bg-gradient-to-r ${skill.color} mb-3`} />
                  <p className="font-semibold text-foreground text-sm">{skill.name}</p>
                  <p className="text-xs text-muted-foreground">{skill.level}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Right Column */}
        <div className="space-y-6">
          {/* AI Recommendations */}
          <motion.div
            className="premium-card"
            variants={itemVariants}
          >
            <div className="flex items-center gap-2 mb-6">
              <Zap className="w-5 h-5 text-accent" />
              <h2 className="text-xl font-bold text-foreground">AI Suggestions</h2>
            </div>

            <div className="space-y-3">
              {[
                'Focus on system design concepts',
                'Practice more algorithmic problems',
                'Take advanced SQL course',
                'Join a study group this week',
              ].map((suggestion, idx) => (
                <motion.div
                  key={idx}
                  className="flex gap-3 p-3 rounded-lg bg-gradient-to-r from-accent/10 to-secondary/10 border border-accent/30 hover:border-accent/50 smooth-transition"
                  whileHover={{ x: 2 }}
                >
                  <div className="text-accent font-bold text-sm pt-0.5">💡</div>
                  <p className="text-sm text-foreground">{suggestion}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Quick Actions */}
          <motion.div
            className="premium-card"
            variants={itemVariants}
          >
            <h2 className="text-lg font-bold text-foreground mb-4">Quick Actions</h2>
            <div className="space-y-2">
              {[
                { label: 'Start Assessment', page: 'assessment', color: 'from-primary' },
                { label: 'View Roadmap', page: 'roadmap', color: 'from-secondary' },
                { label: 'Chat with AI', page: 'chat', color: 'from-accent' },
              ].map((action, idx) => (
                <motion.button
                  key={idx}
                  onClick={() => setCurrentPage(action.page)}
                  className={`w-full p-3 rounded-lg bg-gradient-to-r ${action.color} text-white font-semibold smooth-transition hover:shadow-lg`}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  {action.label}
                </motion.button>
              ))}
            </div>
          </motion.div>

          {/* Next Milestone */}
          <motion.div
            className="premium-card gradient-violet-amber"
            variants={itemVariants}
          >
            <h2 className="text-lg font-bold text-foreground mb-3">Next Milestone</h2>
            <div className="space-y-3">
              <div>
                <p className="text-sm text-muted-foreground mb-2">
                  Complete 10 courses to reach Gold Badge
                </p>
                <div className="w-full bg-white/5 rounded-full h-3">
                  <motion.div
                    className="bg-gradient-to-r from-accent to-amber-500 h-full rounded-full"
                    initial={{ width: 0 }}
                    animate={{ width: '60%' }}
                    transition={{ duration: 1 }}
                  />
                </div>
              </div>
              <p className="text-xs text-muted-foreground">
                6 courses to go • ~2 weeks estimated
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </motion.div>
  )
}
