'use client'

import { motion } from 'framer-motion'
import { TrendingUp, Calendar, Award, Flame } from 'lucide-react'

export function ProgressTracking() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  }

  const weeklyData = [
    { day: 'Mon', hours: 2.5, color: 'from-primary' },
    { day: 'Tue', hours: 3, color: 'from-secondary' },
    { day: 'Wed', hours: 1.5, color: 'from-accent' },
    { day: 'Thu', hours: 4, color: 'from-teal-500' },
    { day: 'Fri', hours: 2.8, color: 'from-violet-500' },
    { day: 'Sat', hours: 3.5, color: 'from-pink-500' },
    { day: 'Sun', hours: 1.2, color: 'from-cyan-500' },
  ]

  return (
    <motion.div
      className="max-w-6xl mx-auto space-y-6"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      <motion.div variants={itemVariants}>
        <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary mb-2">
          Progress Tracking
        </h1>
        <p className="text-muted-foreground">Monitor your learning journey with detailed analytics</p>
      </motion.div>

      {/* Key Metrics */}
      <motion.div
        className="grid grid-cols-1 md:grid-cols-4 gap-4"
        variants={containerVariants}
      >
        {[
          { icon: Flame, label: 'Current Streak', value: '15 days', color: 'from-red-500' },
          { icon: TrendingUp, label: 'Weekly Average', value: '18.5 hrs', color: 'from-primary' },
          { icon: Award, label: 'Achievements', value: '12 badges', color: 'from-accent' },
          { icon: Calendar, label: 'Total Hours', value: '156 hrs', color: 'from-secondary' },
        ].map((metric, idx) => {
          const Icon = metric.icon
          return (
            <motion.div
              key={idx}
              className="premium-card"
              variants={itemVariants}
              whileHover={{ y: -4 }}
            >
              <div className={`inline-block p-3 bg-gradient-to-br ${metric.color} rounded-lg mb-4`}>
                <Icon className="w-6 h-6 text-white" />
              </div>
              <p className="text-muted-foreground text-sm mb-1">{metric.label}</p>
              <p className="text-2xl font-bold text-foreground">{metric.value}</p>
            </motion.div>
          )
        })}
      </motion.div>

      {/* Weekly Activity Chart */}
      <motion.div
        className="premium-card"
        variants={itemVariants}
      >
        <h2 className="text-2xl font-bold text-foreground mb-6">Weekly Learning Hours</h2>
        <div className="flex items-end justify-between h-64 gap-2">
          {weeklyData.map((data, idx) => (
            <motion.div
              key={idx}
              className="flex-1 flex flex-col items-center gap-2"
            >
              <motion.div
                className={`w-full bg-gradient-to-t ${data.color} to-white/20 rounded-t-lg relative group cursor-pointer`}
                initial={{ height: 0 }}
                animate={{ height: `${(data.hours / 4.5) * 100}%` }}
                transition={{ duration: 1, delay: idx * 0.05 }}
                whileHover={{ scale: 1.05 }}
              >
                <div className="absolute -top-8 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 smooth-transition">
                  <div className="bg-card border border-white/20 rounded-lg px-2 py-1 text-xs font-bold text-foreground whitespace-nowrap">
                    {data.hours}h
                  </div>
                </div>
              </motion.div>
              <p className="text-xs font-medium text-muted-foreground">{data.day}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Courses Progress */}
      <motion.div
        className="premium-card"
        variants={itemVariants}
      >
        <h2 className="text-2xl font-bold text-foreground mb-6">Active Courses Progress</h2>
        <div className="space-y-6">
          {[
            {
              name: 'Advanced Python Programming',
              progress: 65,
              modules: '13/20 modules completed',
              color: 'from-blue-500 to-blue-600',
            },
            {
              name: 'Machine Learning Fundamentals',
              progress: 42,
              modules: '8/19 modules completed',
              color: 'from-purple-500 to-purple-600',
            },
            {
              name: 'Web Development with Next.js',
              progress: 28,
              modules: '6/21 modules completed',
              color: 'from-slate-600 to-slate-700',
            },
          ].map((course, idx) => (
            <motion.div
              key={idx}
              className="space-y-3"
              variants={itemVariants}
            >
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-semibold text-foreground">{course.name}</h3>
                  <p className="text-xs text-muted-foreground mt-1">{course.modules}</p>
                </div>
                <span className={`text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r ${course.color}`}>
                  {course.progress}%
                </span>
              </div>
              <div className="w-full bg-white/10 rounded-full h-3 overflow-hidden">
                <motion.div
                  className={`bg-gradient-to-r ${course.color} h-full rounded-full`}
                  initial={{ width: 0 }}
                  animate={{ width: `${course.progress}%` }}
                  transition={{ duration: 1, delay: idx * 0.1 }}
                />
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Skill Growth */}
      <motion.div
        className="premium-card gradient-teal-violet"
        variants={itemVariants}
      >
        <h2 className="text-2xl font-bold text-foreground mb-6">Skill Growth Over Time</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            {
              skill: 'Python',
              initial: 70,
              current: 85,
              growth: '+15%',
              trendColor: 'text-green-400',
            },
            {
              skill: 'System Design',
              initial: 45,
              current: 60,
              growth: '+15%',
              trendColor: 'text-green-400',
            },
            {
              skill: 'React',
              initial: 60,
              current: 78,
              growth: '+18%',
              trendColor: 'text-green-400',
            },
          ].map((skill, idx) => (
            <motion.div
              key={idx}
              className="space-y-3 p-4 rounded-lg border border-white/20 bg-white/5"
              whileHover={{ borderColor: 'rgba(255, 255, 255, 0.3)' }}
            >
              <p className="font-semibold text-foreground">{skill.skill}</p>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">{skill.initial}% →</span>
                <span className={`text-lg font-bold ${skill.trendColor}`}>{skill.current}%</span>
              </div>
              <p className={`text-sm font-semibold ${skill.trendColor}`}>📈 {skill.growth}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Achievements */}
      <motion.div
        className="premium-card"
        variants={itemVariants}
      >
        <h2 className="text-2xl font-bold text-foreground mb-6">Recent Achievements</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { icon: '🔥', label: '7-day Streak', color: 'from-red-500' },
            { icon: '📚', label: '5 Courses', color: 'from-primary' },
            { icon: '🏆', label: 'Top 10%', color: 'from-accent' },
            { icon: '⭐', label: '100 Hours', color: 'from-secondary' },
            { icon: '🎯', label: 'Goal Setter', color: 'from-teal-500' },
            { icon: '🚀', label: 'Fast Learner', color: 'from-violet-500' },
            { icon: '💯', label: 'Perfect Score', color: 'from-pink-500' },
            { icon: '👑', label: 'Elite Status', color: 'from-amber-500' },
          ].map((achievement, idx) => (
            <motion.div
              key={idx}
              className={`p-4 rounded-lg border border-white/20 bg-gradient-to-br ${achievement.color}/10 hover:border-white/40 smooth-transition text-center`}
              whileHover={{ scale: 1.05 }}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: idx * 0.05 }}
            >
              <p className="text-3xl mb-2">{achievement.icon}</p>
              <p className="font-semibold text-sm text-foreground">{achievement.label}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </motion.div>
  )
}
