'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Send, Sparkles, Loader } from 'lucide-react'

interface Message {
  id: string
  type: 'user' | 'assistant'
  content: string
  timestamp: Date
}

export function AIChatAssistant() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'assistant',
      content:
        'Hey! 👋 I\'m your SkillNova AI Learning Assistant. I\'m here to help you with learning guidance, career advice, and personalized study recommendations. What would you like to learn about today?',
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState('')
  const [isLoading, setIsLoading] = useState(false)

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: input,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput('')
    setIsLoading(true)

    // Simulate AI response
    setTimeout(() => {
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content:
          'That\'s a great question! Based on your current skill level and career goals, I recommend focusing on system design first. Your gap analysis shows this is your biggest opportunity area. Would you like me to create a focused learning plan for system design?',
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, aiMessage])
      setIsLoading(false)
    }, 1500)
  }

  const suggestions = [
    'How can I improve my system design skills?',
    'What\'s the best way to prepare for tech interviews?',
    'Recommend courses for my skill gaps',
    'Create a personalized study schedule',
  ]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  }

  return (
    <motion.div
      className="max-w-4xl mx-auto h-[calc(100vh-200px)] flex flex-col"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      {/* Header */}
      <motion.div className="mb-6" variants={itemVariants}>
        <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary mb-2">
          AI Learning Assistant
        </h1>
        <p className="text-muted-foreground">
          Get personalized guidance powered by advanced AI
        </p>
      </motion.div>

      {/* Chat Container */}
      <div className="flex-1 flex flex-col bg-gradient-to-b from-card/50 to-card/20 rounded-3xl border border-white/10 overflow-hidden">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          <AnimatePresence>
            {messages.length === 1 && messages[0].type === 'assistant' && (
              <motion.div
                className="flex justify-center items-center h-full"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
              >
                <div className="text-center space-y-6">
                  <motion.div
                    className="inline-block p-4 rounded-2xl bg-gradient-to-br from-primary to-secondary"
                    animate={{ scale: [1, 1.1, 1], rotate: [0, 5, -5, 0] }}
                    transition={{ duration: 3, repeat: Infinity }}
                  >
                    <Sparkles className="w-8 h-8 text-white" />
                  </motion.div>
                </div>
              </motion.div>
            )}

            {messages.map((message) => (
              <motion.div
                key={message.id}
                className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
              >
                <div
                  className={`max-w-xs lg:max-w-md px-6 py-3 rounded-2xl ${
                    message.type === 'user'
                      ? 'bg-gradient-to-r from-primary to-secondary text-primary-foreground rounded-br-none'
                      : 'glass rounded-bl-none'
                  }`}
                >
                  <p className="text-sm leading-relaxed">{message.content}</p>
                  <p className={`text-xs mt-2 ${
                    message.type === 'user'
                      ? 'text-primary-foreground/70'
                      : 'text-muted-foreground'
                  }`}>
                    {message.timestamp.toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </p>
                </div>
              </motion.div>
            ))}

            {isLoading && (
              <motion.div
                className="flex justify-start"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <div className="glass px-6 py-3 rounded-2xl rounded-bl-none flex items-center gap-2">
                  <Loader className="w-4 h-4 text-primary animate-spin" />
                  <p className="text-sm text-muted-foreground">AI is thinking...</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Suggestions */}
        {messages.length === 1 && (
          <motion.div
            className="p-6 border-t border-white/10 space-y-3"
            variants={containerVariants}
          >
            <p className="text-xs text-muted-foreground font-semibold uppercase">
              Quick Questions
            </p>
            <div className="flex flex-col gap-2">
              {suggestions.map((suggestion, idx) => (
                <motion.button
                  key={idx}
                  onClick={() => {
                    setInput(suggestion)
                  }}
                  className="text-left p-3 rounded-xl glass hover:bg-white/10 smooth-transition"
                  variants={itemVariants}
                  whileHover={{ x: 4 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <p className="text-sm text-foreground font-medium">{suggestion}</p>
                </motion.button>
              ))}
            </div>
          </motion.div>
        )}

        {/* Input Area */}
        <form onSubmit={handleSendMessage} className="p-6 border-t border-white/10">
          <div className="flex gap-3">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask me anything about your learning journey..."
              className="flex-1 premium-input"
              disabled={isLoading}
            />
            <motion.button
              type="submit"
              disabled={isLoading || !input.trim()}
              className="p-3 rounded-xl bg-gradient-to-r from-primary to-secondary text-primary-foreground font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Send className="w-5 h-5" />
            </motion.button>
          </div>
        </form>
      </div>
    </motion.div>
  )
}
