'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import {
  Bell,
  Lock,
  Moon,
  Eye,
  ToggleRight,
  ToggleLeft,
  Save,
  LogOut,
} from 'lucide-react'

export function Settings() {
  const [settings, setSettings] = useState({
    emailNotifications: true,
    pushNotifications: true,
    courseReminders: true,
    weeklyDigest: false,
    darkMode: true,
    twoFactor: false,
    dataCollection: true,
  })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  }

  const toggleSetting = (key: keyof typeof settings) => {
    setSettings((prev) => ({
      ...prev,
      [key]: !prev[key],
    }))
  }

  return (
    <motion.div
      className="max-w-4xl mx-auto space-y-6"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      <motion.div variants={itemVariants}>
        <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary mb-2">
          Settings
        </h1>
        <p className="text-muted-foreground">Manage your preferences and account settings</p>
      </motion.div>

      {/* Notification Settings */}
      <motion.div
        className="premium-card"
        variants={itemVariants}
      >
        <div className="flex items-center gap-3 mb-6">
          <Bell className="w-6 h-6 text-primary" />
          <h2 className="text-2xl font-bold text-foreground">Notifications</h2>
        </div>

        <div className="space-y-4">
          {[
            {
              key: 'emailNotifications',
              label: 'Email Notifications',
              description: 'Receive course updates and progress reports via email',
            },
            {
              key: 'pushNotifications',
              label: 'Push Notifications',
              description: 'Get real-time notifications on your device',
            },
            {
              key: 'courseReminders',
              label: 'Course Reminders',
              description: 'Remind me to complete daily learning goals',
            },
            {
              key: 'weeklyDigest',
              label: 'Weekly Digest',
              description: 'Receive a summary of your weekly progress',
            },
          ].map((notification) => (
            <motion.div
              key={notification.key}
              className="flex items-center justify-between p-4 rounded-lg bg-white/5 border border-white/10 hover:border-white/20 smooth-transition"
              whileHover={{ x: 4 }}
            >
              <div className="flex-1">
                <p className="font-semibold text-foreground">{notification.label}</p>
                <p className="text-sm text-muted-foreground">{notification.description}</p>
              </div>
              <motion.button
                onClick={() => toggleSetting(notification.key as keyof typeof settings)}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
              >
                {settings[notification.key as keyof typeof settings] ? (
                  <ToggleRight className="w-6 h-6 text-primary" />
                ) : (
                  <ToggleLeft className="w-6 h-6 text-muted-foreground" />
                )}
              </motion.button>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Privacy & Security */}
      <motion.div
        className="premium-card"
        variants={itemVariants}
      >
        <div className="flex items-center gap-3 mb-6">
          <Lock className="w-6 h-6 text-secondary" />
          <h2 className="text-2xl font-bold text-foreground">Privacy & Security</h2>
        </div>

        <div className="space-y-4">
          {[
            {
              key: 'twoFactor',
              label: 'Two-Factor Authentication',
              description: 'Add an extra layer of security to your account',
              status: '✓ Not enabled',
              statusColor: 'text-muted-foreground',
            },
            {
              key: 'dataCollection',
              label: 'Allow Data Collection',
              description: 'Help improve SkillNova by sharing usage analytics',
            },
          ].map((security) => (
            <motion.div
              key={security.key}
              className="flex items-center justify-between p-4 rounded-lg bg-white/5 border border-white/10 hover:border-white/20 smooth-transition"
              whileHover={{ x: 4 }}
            >
              <div className="flex-1">
                <p className="font-semibold text-foreground">{security.label}</p>
                <p className="text-sm text-muted-foreground">{security.description}</p>
              </div>
              <motion.button
                onClick={() => toggleSetting(security.key as keyof typeof settings)}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
              >
                {settings[security.key as keyof typeof settings] ? (
                  <ToggleRight className="w-6 h-6 text-primary" />
                ) : (
                  <ToggleLeft className="w-6 h-6 text-muted-foreground" />
                )}
              </motion.button>
            </motion.div>
          ))}

          {/* Password Change */}
          <motion.div
            className="p-4 rounded-lg bg-white/5 border border-white/10 hover:border-white/20 smooth-transition"
            whileHover={{ x: 4 }}
          >
            <p className="font-semibold text-foreground mb-3">Change Password</p>
            <motion.button
              className="px-4 py-2 rounded-lg bg-gradient-to-r from-primary to-secondary text-primary-foreground font-semibold"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              Update Password
            </motion.button>
          </motion.div>
        </div>
      </motion.div>

      {/* Display & Appearance */}
      <motion.div
        className="premium-card"
        variants={itemVariants}
      >
        <div className="flex items-center gap-3 mb-6">
          <Moon className="w-6 h-6 text-accent" />
          <h2 className="text-2xl font-bold text-foreground">Appearance</h2>
        </div>

        <div className="space-y-4">
          <motion.div
            className="flex items-center justify-between p-4 rounded-lg bg-white/5 border border-white/10 hover:border-white/20 smooth-transition"
            whileHover={{ x: 4 }}
          >
            <div className="flex-1">
              <p className="font-semibold text-foreground">Dark Mode</p>
              <p className="text-sm text-muted-foreground">Use dark theme for easier on eyes</p>
            </div>
            <motion.button
              onClick={() => toggleSetting('darkMode')}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              {settings.darkMode ? (
                <ToggleRight className="w-6 h-6 text-primary" />
              ) : (
                <ToggleLeft className="w-6 h-6 text-muted-foreground" />
              )}
            </motion.button>
          </motion.div>

          {/* Language */}
          <motion.div
            className="p-4 rounded-lg bg-white/5 border border-white/10 hover:border-white/20 smooth-transition"
            whileHover={{ x: 4 }}
          >
            <p className="font-semibold text-foreground mb-3">Language</p>
            <select className="premium-input w-full">
              <option>English</option>
              <option>Spanish</option>
              <option>French</option>
              <option>German</option>
              <option>Chinese</option>
              <option>Japanese</option>
            </select>
          </motion.div>
        </div>
      </motion.div>

      {/* Account Management */}
      <motion.div
        className="premium-card"
        variants={itemVariants}
      >
        <div className="flex items-center gap-3 mb-6">
          <Eye className="w-6 h-6 text-muted-foreground" />
          <h2 className="text-2xl font-bold text-foreground">Account Management</h2>
        </div>

        <div className="space-y-3">
          {[
            {
              title: 'Download Your Data',
              description: 'Get a copy of all your data',
              color: 'glass',
            },
            {
              title: 'Delete Account',
              description: 'Permanently delete your account and all data',
              color: 'border-destructive/50 bg-destructive/10',
            },
          ].map((action, idx) => (
            <motion.button
              key={idx}
              className={`w-full p-4 rounded-lg border ${
                action.color
              } hover:border-opacity-100 smooth-transition text-left`}
              whileHover={{ x: 4 }}
              whileTap={{ scale: 0.98 }}
            >
              <p className={`font-semibold ${
                idx === 1 ? 'text-destructive' : 'text-foreground'
              }`}>
                {action.title}
              </p>
              <p className="text-sm text-muted-foreground">{action.description}</p>
            </motion.button>
          ))}
        </div>
      </motion.div>

      {/* Action Buttons */}
      <motion.div
        className="flex gap-4"
        variants={itemVariants}
      >
        <motion.button
          className="flex-1 py-3 rounded-xl bg-gradient-to-r from-primary via-secondary to-accent text-primary-foreground font-bold premium-btn flex items-center justify-center gap-2"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <Save className="w-5 h-5" />
          Save Changes
        </motion.button>
        <motion.button
          className="flex-1 py-3 rounded-xl glass premium-btn flex items-center justify-center gap-2"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <LogOut className="w-5 h-5" />
          Sign Out
        </motion.button>
      </motion.div>

      {/* Footer Info */}
      <motion.div
        className="p-4 rounded-lg bg-white/5 border border-white/10 text-center space-y-2"
        variants={itemVariants}
      >
        <p className="text-sm text-muted-foreground">
          SkillNova v2.1.0 • Last updated: Today
        </p>
        <p className="text-xs text-muted-foreground">
          Questions? Check our{' '}
          <a href="#" className="text-primary hover:text-primary/80">
            Help Center
          </a>
        </p>
      </motion.div>
    </motion.div>
  )
}
