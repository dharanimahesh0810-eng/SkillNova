'use client'

import { motion } from 'framer-motion'
import { CheckCircle, Circle, Lock, Zap, Calendar } from 'lucide-react'

export function LearningRoadmap() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: {
      opacity: 1,
      x: 0,
      transition: { duration: 0.5 },
    },
  }

  const roadmapPhases = [
    {
      phase: 'Phase 1: Fundamentals',
      duration: '4 weeks',
      status: 'completed',
      milestones: [
        { title: 'Python Mastery', completed: true, duration: '1 week' },
        { title: 'Data Structures Basics', completed: true, duration: '1 week' },
        { title: 'Algorithm Fundamentals', completed: true, duration: '1 week' },
        { title: 'Problem Solving 101', completed: true, duration: '1 week' },
      ],
    },
    {
      phase: 'Phase 2: Intermediate Concepts',
      duration: '6 weeks',
      status: 'in-progress',
      milestones: [
        { title: 'Advanced Algorithms', completed: true, duration: '1.5 weeks' },
        { title: 'System Design Basics', completed: false, duration: '2 weeks' },
        { title: 'Database Design', completed: false, duration: '1.5 weeks' },
        { title: 'Web Development Fundamentals', completed: false, duration: '1 week' },
      ],
    },
    {
      phase: 'Phase 3: Advanced Topics',
      duration: '8 weeks',
      status: 'pending',
      milestones: [
        { title: 'Advanced System Design', completed: false, duration: '2 weeks' },
        { title: 'Distributed Systems', completed: false, duration: '2 weeks' },
        { title: 'Cloud Architecture', completed: false, duration: '2 weeks' },
        { title: 'DevOps & Deployment', completed: false, duration: '2 weeks' },
      ],
    },
    {
      phase: 'Phase 4: Specialization',
      duration: '6 weeks',
      status: 'pending',
      milestones: [
        { title: 'Full-Stack Development', completed: false, duration: '2 weeks' },
        { title: 'ML & AI Basics', completed: false, duration: '2 weeks' },
        { title: 'Performance Optimization', completed: false, duration: '1 week' },
        { title: 'Interview Preparation', completed: false, duration: '1 week' },
      ],
    },
  ]

  return (
    <motion.div
      className="max-w-5xl mx-auto space-y-6"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      <motion.div variants={itemVariants}>
        <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary mb-2">
          Personalized Learning Roadmap
        </h1>
        <p className="text-muted-foreground">24-week AI-optimized learning path to achieve your career goals</p>
      </motion.div>

      {/* Timeline */}
      <motion.div
        className="relative"
        variants={itemVariants}
      >
        {roadmapPhases.map((phase, phaseIdx) => {
          const isCompleted = phase.status === 'completed'
          const isInProgress = phase.status === 'in-progress'

          return (
            <motion.div
              key={phaseIdx}
              className="mb-12"
              variants={itemVariants}
            >
              {/* Phase Header */}
              <div className="flex items-start gap-4 mb-6">
                <div className="flex flex-col items-center">
                  <motion.div
                    className={`w-12 h-12 rounded-full flex items-center justify-center font-bold text-white mb-2 ${
                      isCompleted
                        ? 'bg-gradient-to-br from-primary to-teal-500'
                        : isInProgress
                          ? 'bg-gradient-to-br from-accent to-amber-500'
                          : 'bg-white/10 border-2 border-white/20'
                    }`}
                    whileHover={{ scale: 1.1 }}
                  >
                    {isCompleted ? (
                      <CheckCircle className="w-6 h-6" />
                    ) : isInProgress ? (
                      <Zap className="w-6 h-6" />
                    ) : (
                      phaseIdx + 1
                    )}
                  </motion.div>

                  {phaseIdx < roadmapPhases.length - 1 && (
                    <motion.div
                      className={`w-1 ${
                        isCompleted ? 'bg-primary/50' : 'bg-white/10'
                      } flex-1 min-h-[200px]`}
                    />
                  )}
                </div>

                <div className="flex-1 pt-2">
                  <div className="flex items-center gap-3 mb-2">
                    <h2 className="text-2xl font-bold text-foreground">{phase.phase}</h2>
                    <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                      isCompleted
                        ? 'bg-primary/20 text-primary'
                        : isInProgress
                          ? 'bg-accent/20 text-accent'
                          : 'bg-white/10 text-muted-foreground'
                    }`}>
                      {phase.status.charAt(0).toUpperCase() + phase.status.slice(1)}
                    </span>
                  </div>
                  <div className="flex items-center gap-4 text-muted-foreground">
                    <Calendar className="w-4 h-4" />
                    <span>{phase.duration}</span>
                  </div>
                </div>
              </div>

              {/* Milestones */}
              <div className="ml-16 space-y-3">
                {phase.milestones.map((milestone, midIdx) => (
                  <motion.div
                    key={midIdx}
                    className={`premium-card ${
                      milestone.completed
                        ? 'border-primary/50 bg-gradient-to-r from-primary/10 to-teal-500/10'
                        : 'border-white/10 opacity-60'
                    }`}
                    variants={itemVariants}
                    whileHover={{ x: 4 }}
                  >
                    <div className="flex items-center gap-4">
                      {milestone.completed ? (
                        <CheckCircle className="w-5 h-5 text-primary flex-shrink-0" />
                      ) : (
                        <Circle className="w-5 h-5 text-white/30 flex-shrink-0" />
                      )}

                      <div className="flex-1">
                        <p className={`font-semibold ${
                          milestone.completed ? 'text-foreground' : 'text-muted-foreground'
                        }`}>
                          {milestone.title}
                        </p>
                      </div>

                      <span className="text-xs text-muted-foreground">{milestone.duration}</span>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )
        })}
      </motion.div>

      {/* Statistics */}
      <motion.div
        className="grid grid-cols-1 md:grid-cols-3 gap-4"
        variants={containerVariants}
      >
        {[
          { label: 'Completed', value: '4/16', color: 'from-primary' },
          { label: 'In Progress', value: '4/16', color: 'from-accent' },
          { label: 'Remaining', value: '8/16', color: 'from-secondary' },
        ].map((stat, idx) => (
          <motion.div
            key={idx}
            className="premium-card"
            variants={itemVariants}
            whileHover={{ y: -4 }}
          >
            <p className="text-muted-foreground text-sm mb-2">{stat.label}</p>
            <div className="flex items-baseline gap-2">
              <span className={`text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r ${stat.color}`}>
                {stat.value.split('/')[0]}
              </span>
              <span className="text-muted-foreground">of {stat.value.split('/')[1]}</span>
            </div>
          </motion.div>
        ))}
      </motion.div>

      {/* Next Steps */}
      <motion.div
        className="premium-card gradient-teal-violet"
        variants={itemVariants}
      >
        <h2 className="text-xl font-bold text-foreground mb-4">Your Next Steps</h2>
        <div className="space-y-3">
          {[
            '📚 Complete "System Design Basics" course (started, 60% done)',
            '💻 Solve 5 system design problems on LeetCode',
            '🎯 Schedule 1-on-1 mentor session for system design review',
            '📖 Read "Designing Data-Intensive Applications" Chapter 1',
          ].map((step, idx) => (
            <motion.div
              key={idx}
              className="flex items-start gap-3 p-3 rounded-lg bg-white/5 hover:bg-white/8 smooth-transition"
              whileHover={{ x: 4 }}
            >
              <span className="text-lg flex-shrink-0">{idx + 1}️⃣</span>
              <p className="text-foreground">{step}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </motion.div>
  )
}
