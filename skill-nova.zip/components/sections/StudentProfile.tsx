'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Mail, Phone, MapPin, Briefcase, GraduationCap, Upload, Edit2, Save, X } from 'lucide-react'

interface UserData {
  email: string
  name: string
  password: string
}

interface StudentProfileProps {
  userData: UserData
}



export function StudentProfile({ userData }: StudentProfileProps) {
  // Generate unique profile for user based on their email
  const getProfileData = () => {
    // Use email to generate consistent but unique profile data
    const userNumber = userData.email.charCodeAt(0) + userData.email.charCodeAt(userData.email.length - 1)
    const majorOptions = ['Computer Science', 'Data Science', 'Electrical Engineering', 'Business Administration', 'Information Technology', 'Software Engineering']
    const yearOptions = ['Year 1', 'Year 2', 'Year 3', 'Year 4']
    const goalOptions = [
      'Full-Stack Software Engineer',
      'Machine Learning Engineer',
      'Cloud Solutions Architect',
      'Product Manager',
      'DevOps Engineer',
      'Mobile App Developer',
      'AI Research Scientist',
      'Frontend Developer',
      'Backend Developer',
      'Data Engineer'
    ]
    
    const majorIdx = userNumber % majorOptions.length
    const yearIdx = (userNumber + 1) % yearOptions.length
    const goalIdx = (userNumber + 2) % goalOptions.length
    
    return {
      name: userData.name,
      initials: userData.name.split(' ').map((n: string) => n[0]).join(''),
      major: majorOptions[majorIdx],
      year: yearOptions[yearIdx],
      phone: `+1 (555) ${String(userNumber % 1000).padStart(3, '0')}-${String((userNumber * 7) % 10000).padStart(4, '0')}`,
      location: ['San Francisco, CA', 'New York, NY', 'Austin, TX', 'Seattle, WA', 'Boston, MA', 'Chicago, IL'][userNumber % 6],
      graduation: `May ${2025 + (userNumber % 3)}`,
      primaryGoal: goalOptions[goalIdx],
      timeline: ['6-12 months', '12-18 months', '18-24 months', '24+ months'][userNumber % 4],
      keySkills: ['Web Development, Cloud Computing, System Design', 
                  'Machine Learning, Statistics, Deep Learning',
                  'Hardware Design, C++, IoT Protocols',
                  'Product Strategy, Analytics, Leadership'][majorIdx % 4],
      certifications: [
        { name: `${['AWS', 'Google Cloud', 'Azure', 'Kubernetes'][userNumber % 4]} Certified`, issuer: `${['Amazon', 'Google', 'Microsoft', 'Linux Foundation'][userNumber % 4]}`, date: 'Jan 2024' },
        { name: `${['Advanced Python', 'React Patterns', 'System Design', 'Data Analytics'][userNumber % 4]} Professional`, issuer: `${['Coursera', 'Udemy', 'Pluralsight', 'DataCamp'][userNumber % 4]}`, date: 'Nov 2023' },
      ]
    }
  }

  const initialProfile = getProfileData()
  const [isEditing, setIsEditing] = useState(false)
  const [profile, setProfile] = useState(initialProfile)
  const [editedProfile, setEditedProfile] = useState(initialProfile)

  const handleEdit = () => {
    setIsEditing(true)
    setEditedProfile(profile)
  }

  const handleSave = () => {
    setProfile(editedProfile)
    setIsEditing(false)
  }

  const handleCancel = () => {
    setEditedProfile(profile)
    setIsEditing(false)
  }

  const handleInputChange = (field: string, value: string) => {
    setEditedProfile(prev => ({
      ...prev,
      [field]: value
    }))
  }
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  }

  return (
    <motion.div
      className="max-w-4xl mx-auto space-y-6"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      <motion.div variants={itemVariants}>
        <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary mb-2">
          Student Profile
        </h1>
        <p className="text-muted-foreground">Manage your personal information and career goals</p>
      </motion.div>

      {/* Profile Header */}
      <motion.div
        className="premium-card"
        variants={itemVariants}
      >
        <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
          <div className="relative">
            <div className="w-32 h-32 rounded-2xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white text-4xl font-bold">
              {profile.initials}
            </div>
            <motion.button
              className="absolute bottom-0 right-0 p-2 rounded-lg bg-accent text-accent-foreground shadow-lg"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              <Upload className="w-5 h-5" />
            </motion.button>
          </div>

          <div className="flex-1">
            <h2 className="text-3xl font-bold text-foreground mb-1">{profile.name}</h2>
            <div className="flex items-center gap-2 text-muted-foreground mb-4">
              <GraduationCap className="w-4 h-4" />
              <span>{profile.major} Student • {profile.year}</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {!isEditing ? (
                <>
                  <motion.button
                    onClick={handleEdit}
                    className="premium-btn px-4 py-2 bg-primary text-primary-foreground"
                    whileHover={{ scale: 1.05 }}
                  >
                    <Edit2 className="w-4 h-4 mr-2 inline" />
                    Edit Profile
                  </motion.button>
                  <motion.button
                    className="premium-btn px-4 py-2 glass"
                    whileHover={{ scale: 1.05 }}
                  >
                    Download Resume
                  </motion.button>
                </>
              ) : (
                <>
                  <motion.button
                    onClick={handleSave}
                    className="premium-btn px-4 py-2 bg-primary text-primary-foreground"
                    whileHover={{ scale: 1.05 }}
                  >
                    <Save className="w-4 h-4 mr-2 inline" />
                    Save Changes
                  </motion.button>
                  <motion.button
                    onClick={handleCancel}
                    className="premium-btn px-4 py-2 glass text-foreground"
                    whileHover={{ scale: 1.05 }}
                  >
                    <X className="w-4 h-4 mr-2 inline" />
                    Cancel
                  </motion.button>
                </>
              )}
            </div>
          </div>
        </div>
      </motion.div>

      {/* Contact Information */}
      <motion.div
        className="premium-card"
        variants={itemVariants}
      >
        <h3 className="text-xl font-bold text-foreground mb-4">Contact Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            { icon: Mail, label: 'Email', field: 'email', value: userData.email, editable: false },
            { icon: Phone, label: 'Phone', field: 'phone', value: isEditing ? editedProfile.phone : profile.phone, editable: true },
            { icon: MapPin, label: 'Location', field: 'location', value: isEditing ? editedProfile.location : profile.location, editable: true },
            { icon: Briefcase, label: 'Expected Graduation', field: 'graduation', value: isEditing ? editedProfile.graduation : profile.graduation, editable: true },
          ].map((item, idx) => {
            const Icon = item.icon
            return (
              <motion.div
                key={idx}
                className="p-4 rounded-lg bg-white/5 border border-white/10"
                whileHover={{ borderColor: 'rgba(0, 201, 167, 0.5)' }}
              >
                <div className="flex items-center gap-3">
                  <Icon className="w-5 h-5 text-primary" />
                  <div className="flex-1">
                    <p className="text-xs text-muted-foreground">{item.label}</p>
                    {isEditing && item.editable ? (
                      <input
                        type="text"
                        value={item.value}
                        onChange={(e) => handleInputChange(item.field, e.target.value)}
                        className="premium-input w-full text-sm font-semibold"
                      />
                    ) : (
                      <p className="font-semibold text-foreground">{item.value}</p>
                    )}
                  </div>
                </div>
              </motion.div>
            )
          })}
        </div>
      </motion.div>

      {/* Career Goals */}
      <motion.div
        className="premium-card"
        variants={itemVariants}
      >
        <h3 className="text-xl font-bold text-foreground mb-4">Career Goals</h3>
        <div className="space-y-4">
          {[
            { title: 'Primary Goal', field: 'primaryGoal', value: isEditing ? editedProfile.primaryGoal : profile.primaryGoal },
            { title: 'Timeline', field: 'timeline', value: isEditing ? editedProfile.timeline : profile.timeline },
            { title: 'Key Skills to Develop', field: 'keySkills', value: isEditing ? editedProfile.keySkills : profile.keySkills },
          ].map((goal, idx) => (
            <div key={idx} className="p-4 rounded-lg bg-gradient-to-r from-secondary/10 to-violet-500/10 border border-secondary/30">
              <p className="text-xs text-muted-foreground mb-1">{goal.title}</p>
              {isEditing ? (
                <textarea
                  value={goal.value}
                  onChange={(e) => handleInputChange(goal.field, e.target.value)}
                  className="premium-input w-full font-medium min-h-[60px] resize-none"
                />
              ) : (
                <p className="text-foreground font-medium">{goal.value}</p>
              )}
            </div>
          ))}
        </div>
      </motion.div>

      {/* Certifications */}
      <motion.div
        className="premium-card"
        variants={itemVariants}
      >
        <h3 className="text-xl font-bold text-foreground mb-4">Certifications & Achievements</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {profile.certifications.map((cert, idx) => (
            <motion.div
              key={idx}
              className="p-4 rounded-lg border border-accent/50 bg-gradient-to-br from-accent/10 to-amber-500/10"
              whileHover={{ scale: 1.02 }}
            >
              <p className="font-semibold text-foreground text-sm mb-1">✓ {cert.name}</p>
              <p className="text-xs text-muted-foreground">{cert.issuer} • {cert.date}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </motion.div>
  )
}
