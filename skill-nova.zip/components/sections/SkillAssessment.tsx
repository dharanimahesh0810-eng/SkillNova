'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { PlayCircle, CheckCircle, Clock, Zap } from 'lucide-react'

export function SkillAssessment() {
  const [selectedAssessment, setSelectedAssessment] = useState<string | null>(null)
  const [progress, setProgress] = useState(0)

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  }

  const assessments = [
    {
      id: 'python-basics',
      name: 'Python Basics',
      category: 'Programming',
      difficulty: 'Beginner',
      questions: 15,
      time: '20 min',
      status: 'completed',
      score: 92,
    },
    {
      id: 'javascript-advanced',
      name: 'JavaScript Advanced',
      category: 'Web Development',
      difficulty: 'Advanced',
      questions: 25,
      time: '45 min',
      status: 'in-progress',
      score: 68,
    },
    {
      id: 'data-structures',
      name: 'Data Structures & Algorithms',
      category: 'CS Fundamentals',
      difficulty: 'Intermediate',
      questions: 30,
      time: '60 min',
      status: 'pending',
      score: 0,
    },
    {
      id: 'system-design',
      name: 'System Design',
      category: 'Advanced Topics',
      difficulty: 'Advanced',
      questions: 20,
      time: '50 min',
      status: 'pending',
      score: 0,
    },
    {
      id: 'sql-optimization',
      name: 'SQL & Database Optimization',
      category: 'Backend',
      difficulty: 'Intermediate',
      questions: 20,
      time: '40 min',
      status: 'completed',
      score: 87,
    },
    {
      id: 'react-ecosystem',
      name: 'React Ecosystem',
      category: 'Frontend',
      difficulty: 'Intermediate',
      questions: 25,
      time: '45 min',
      status: 'pending',
      score: 0,
    },
  ]

  return (
    <motion.div
      className="max-w-6xl mx-auto space-y-6"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      <motion.div variants={itemVariants}>
        <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary mb-2">
          Skill Assessment
        </h1>
        <p className="text-muted-foreground">Evaluate your skills and identify areas for improvement</p>
      </motion.div>

      {/* Assessment Modal */}
      {selectedAssessment && (
        <motion.div
          className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          onClick={() => setSelectedAssessment(null)}
        >
          <motion.div
            className="premium-card max-w-2xl w-full"
            onClick={(e) => e.stopPropagation()}
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
          >
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-foreground mb-4">
                {assessments.find((a) => a.id === selectedAssessment)?.name}
              </h2>
              <div className="w-full bg-white/10 rounded-full h-2">
                <motion.div
                  className="bg-gradient-to-r from-primary to-secondary h-full rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 0.5 }}
                />
              </div>
              <p className="text-sm text-muted-foreground mt-2">{progress}% complete</p>
            </div>

            {/* Sample Question */}
            <div className="space-y-4 mb-6">
              <p className="font-semibold text-foreground">Question 1 of 15</p>
              <div className="p-4 bg-white/5 rounded-lg border border-white/10">
                <p className="text-foreground mb-4">
                  What is the time complexity of binary search on a sorted array?
                </p>
                <div className="space-y-2">
                  {['O(n)', 'O(log n)', 'O(n²)', 'O(2ⁿ)'].map((option, idx) => (
                    <motion.button
                      key={idx}
                      className="w-full p-3 text-left rounded-lg bg-white/5 border border-white/10 hover:border-primary/50 smooth-transition"
                      whileHover={{ x: 4, borderColor: '#00c9a7' }}
                      whileTap={{ scale: 0.98 }}
                    >
                      {option}
                    </motion.button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <motion.button
                onClick={() => setProgress(Math.min(100, progress + 10))}
                className="flex-1 premium-btn py-3 bg-primary text-primary-foreground"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                Next Question
              </motion.button>
              <motion.button
                onClick={() => setSelectedAssessment(null)}
                className="flex-1 premium-btn py-3 glass"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                Exit
              </motion.button>
            </div>
          </motion.div>
        </motion.div>
      )}

      {/* Assessments Grid */}
      <motion.div
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
        variants={containerVariants}
      >
        {assessments.map((assessment) => {
          const isCompleted = assessment.status === 'completed'
          const isInProgress = assessment.status === 'in-progress'

          return (
            <motion.div
              key={assessment.id}
              className={`premium-card relative overflow-hidden group cursor-pointer ${
                isCompleted ? 'border-primary/50' : 'border-white/10'
              }`}
              variants={itemVariants}
              whileHover={{ y: -4 }}
              onClick={() => {
                setSelectedAssessment(assessment.id)
                setProgress(isInProgress ? 68 : 0)
              }}
            >
              {/* Background gradient */}
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 bg-gradient-to-br from-primary/10 to-secondary/10 smooth-transition" />

              <div className="relative z-10 space-y-4">
                {/* Header */}
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <span className={`text-xs px-2 py-1 rounded-full font-semibold ${
                        assessment.difficulty === 'Beginner'
                          ? 'bg-green-500/20 text-green-300'
                          : assessment.difficulty === 'Intermediate'
                            ? 'bg-yellow-500/20 text-yellow-300'
                            : 'bg-red-500/20 text-red-300'
                      }`}>
                        {assessment.difficulty}
                      </span>
                    </div>
                    <h3 className="font-bold text-foreground text-lg">{assessment.name}</h3>
                    <p className="text-xs text-muted-foreground mt-1">{assessment.category}</p>
                  </div>

                  {isCompleted && (
                    <CheckCircle className="w-6 h-6 text-primary flex-shrink-0" />
                  )}
                </div>

                {/* Stats */}
                <div className="flex items-center gap-4 text-sm">
                  <span className="flex items-center gap-1 text-muted-foreground">
                    <span>❓</span> {assessment.questions} Questions
                  </span>
                  <span className="flex items-center gap-1 text-muted-foreground">
                    <Clock className="w-4 h-4" /> {assessment.time}
                  </span>
                </div>

                {/* Progress or Score */}
                {isInProgress && (
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-xs text-muted-foreground">In Progress</span>
                      <span className="text-sm font-semibold text-primary">{assessment.score}%</span>
                    </div>
                    <div className="w-full bg-white/10 rounded-full h-2">
                      <motion.div
                        className="bg-gradient-to-r from-primary to-secondary h-full rounded-full"
                        initial={{ width: 0 }}
                        animate={{ width: `${assessment.score}%` }}
                        transition={{ duration: 1 }}
                      />
                    </div>
                  </div>
                )}

                {isCompleted && (
                  <div className="p-3 rounded-lg bg-gradient-to-r from-primary/10 to-secondary/10 border border-primary/30">
                    <p className="text-xs text-muted-foreground mb-1">Score</p>
                    <p className="text-2xl font-bold text-primary">{assessment.score}%</p>
                  </div>
                )}

                {assessment.status === 'pending' && (
                  <motion.button
                    className="w-full py-2 rounded-lg bg-gradient-to-r from-primary to-secondary text-primary-foreground font-semibold smooth-transition group-hover:shadow-lg group-hover:shadow-primary/50"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <PlayCircle className="w-4 h-4 inline mr-2" />
                    Start Assessment
                  </motion.button>
                )}

                {isInProgress && (
                  <motion.button
                    className="w-full py-2 rounded-lg bg-gradient-to-r from-accent to-amber-500 text-accent-foreground font-semibold smooth-transition"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <Zap className="w-4 h-4 inline mr-2" />
                    Continue
                  </motion.button>
                )}

                {isCompleted && (
                  <motion.button
                    className="w-full py-2 rounded-lg glass font-semibold smooth-transition"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    Review Results
                  </motion.button>
                )}
              </div>
            </motion.div>
          )
        })}
      </motion.div>
    </motion.div>
  )
}
