'use client'

import { motion } from 'framer-motion'
import { TrendingUp, Target, Lightbulb, AlertCircle } from 'lucide-react'

export function SkillGapAnalysis() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  }

  const skills = [
    { name: 'Python', current: 85, target: 95, gap: 10, priority: 'high' },
    { name: 'System Design', current: 60, target: 90, gap: 30, priority: 'high' },
    { name: 'React', current: 78, target: 92, gap: 14, priority: 'medium' },
    { name: 'TypeScript', current: 70, target: 88, gap: 18, priority: 'medium' },
    { name: 'Cloud Architecture', current: 45, target: 80, gap: 35, priority: 'high' },
    { name: 'DevOps', current: 50, target: 75, gap: 25, priority: 'medium' },
  ]

  return (
    <motion.div
      className="max-w-5xl mx-auto space-y-6"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      <motion.div variants={itemVariants}>
        <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary mb-2">
          AI Skill Gap Analysis
        </h1>
        <p className="text-muted-foreground">Intelligent analysis of your current skills vs. your career goals</p>
      </motion.div>

      {/* Summary Cards */}
      <motion.div
        className="grid grid-cols-1 md:grid-cols-3 gap-4"
        variants={containerVariants}
      >
        {[
          { icon: TrendingUp, label: 'Average Proficiency', value: '68%', color: 'from-primary' },
          { icon: Target, label: 'Target Average', value: '88%', color: 'from-secondary' },
          { icon: AlertCircle, label: 'High Priority Gaps', value: '3', color: 'from-accent' },
        ].map((stat, idx) => {
          const Icon = stat.icon
          return (
            <motion.div
              key={idx}
              className="premium-card"
              variants={itemVariants}
              whileHover={{ y: -4 }}
            >
              <div className={`inline-block p-3 bg-gradient-to-br ${stat.color} rounded-lg mb-4`}>
                <Icon className="w-6 h-6 text-white" />
              </div>
              <p className="text-muted-foreground text-sm mb-1">{stat.label}</p>
              <p className="text-2xl font-bold text-foreground">{stat.value}</p>
            </motion.div>
          )
        })}
      </motion.div>

      {/* Skills Analysis */}
      <motion.div
        className="premium-card"
        variants={itemVariants}
      >
        <h2 className="text-2xl font-bold text-foreground mb-6">Detailed Skill Analysis</h2>

        <div className="space-y-6">
          {skills.map((skill, idx) => (
            <motion.div
              key={idx}
              className="p-4 rounded-xl border border-white/10 bg-gradient-to-r from-white/5 to-white/0 hover:border-primary/50 smooth-transition"
              whileHover={{ x: 4 }}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <h3 className="font-semibold text-foreground mb-1">{skill.name}</h3>
                  <div className="flex items-center gap-4 text-sm">
                    <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                      skill.priority === 'high'
                        ? 'bg-red-500/20 text-red-300'
                        : 'bg-yellow-500/20 text-yellow-300'
                    }`}>
                      {skill.priority === 'high' ? '🔴 High Priority' : '🟡 Medium Priority'}
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xs text-muted-foreground mb-1">Gap to Close</p>
                  <p className="text-2xl font-bold text-accent">{skill.gap}%</p>
                </div>
              </div>

              {/* Progress Bars */}
              <div className="space-y-2">
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-xs text-muted-foreground">Current Level</span>
                    <span className="text-sm font-semibold text-foreground">{skill.current}%</span>
                  </div>
                  <div className="w-full bg-white/5 rounded-full h-2">
                    <motion.div
                      className="bg-gradient-to-r from-primary to-teal-500 h-full rounded-full"
                      initial={{ width: 0 }}
                      animate={{ width: `${skill.current}%` }}
                      transition={{ duration: 1, delay: idx * 0.05 }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-xs text-muted-foreground">Target Level</span>
                    <span className="text-sm font-semibold text-foreground">{skill.target}%</span>
                  </div>
                  <div className="w-full bg-white/5 rounded-full h-2">
                    <motion.div
                      className="bg-gradient-to-r from-secondary to-violet-600 h-full rounded-full"
                      initial={{ width: 0 }}
                      animate={{ width: `${skill.target}%` }}
                      transition={{ duration: 1, delay: idx * 0.05 + 0.2 }}
                    />
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* AI Recommendations */}
      <motion.div
        className="premium-card gradient-violet-amber"
        variants={itemVariants}
      >
        <div className="flex items-center gap-3 mb-4">
          <Lightbulb className="w-6 h-6 text-accent" />
          <h2 className="text-2xl font-bold text-foreground">AI-Powered Recommendations</h2>
        </div>

        <div className="space-y-4">
          {[
            {
              title: 'Focus on System Design First',
              description: 'This is your biggest gap (35%) and critical for your career goals. Complete our Advanced System Design course.',
              priority: 'Urgent',
            },
            {
              title: 'Build Cloud Architecture Skills',
              description: 'Cloud expertise is highly demanded. Start with AWS Solutions Architect course to bridge the 35% gap.',
              priority: 'Urgent',
            },
            {
              title: 'Strengthen TypeScript Fundamentals',
              description: 'TypeScript proficiency improves React mastery. Complete 10 practical exercises this week.',
              priority: 'High',
            },
            {
              title: 'Learn DevOps Basics',
              description: 'DevOps skills complement your backend expertise. Start with Docker and Kubernetes fundamentals.',
              priority: 'High',
            },
          ].map((rec, idx) => (
            <motion.div
              key={idx}
              className="p-4 rounded-lg border border-white/20 bg-white/8 hover:border-primary/50 smooth-transition"
              whileHover={{ x: 4 }}
            >
              <div className="flex items-start gap-3">
                <span className={`mt-1 px-2 py-1 rounded text-xs font-bold flex-shrink-0 ${
                  rec.priority === 'Urgent'
                    ? 'bg-red-500/30 text-red-200'
                    : 'bg-amber-500/30 text-amber-200'
                }`}>
                  {rec.priority}
                </span>
                <div className="flex-1">
                  <p className="font-semibold text-foreground mb-1">{rec.title}</p>
                  <p className="text-sm text-muted-foreground">{rec.description}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </motion.div>
  )
}
