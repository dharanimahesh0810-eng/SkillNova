'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { BookOpen, Users, Star, Clock, Play, Bookmark } from 'lucide-react'

export function CourseRecommendations() {
  const [savedCourses, setSavedCourses] = useState<string[]>([])

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  }

  const courses = [
    {
      id: 'sd-1',
      title: 'Advanced System Design',
      description: 'Master distributed systems, scalability, and production architecture patterns.',
      level: 'Advanced',
      duration: '12 weeks',
      students: 8400,
      rating: 4.9,
      price: '149',
      image: 'bg-gradient-to-br from-violet-600 to-violet-800',
      progress: 0,
      modules: 24,
    },
    {
      id: 'ml-1',
      title: 'Machine Learning Engineering',
      description: 'Learn ML pipelines, model optimization, and production deployment.',
      level: 'Advanced',
      duration: '10 weeks',
      students: 5200,
      rating: 4.8,
      price: '129',
      image: 'bg-gradient-to-br from-pink-600 to-pink-800',
      progress: 0,
      modules: 20,
    },
    {
      id: 'cloud-1',
      title: 'AWS Solutions Architecture',
      description: 'Design scalable, secure, and efficient systems on AWS cloud.',
      level: 'Intermediate',
      duration: '8 weeks',
      students: 12600,
      rating: 4.7,
      price: '99',
      image: 'bg-gradient-to-br from-orange-600 to-orange-800',
      progress: 0,
      modules: 18,
    },
    {
      id: 'docker-1',
      title: 'Docker & Kubernetes Mastery',
      description: 'Containerize applications and orchestrate with Kubernetes.',
      level: 'Intermediate',
      duration: '6 weeks',
      students: 9800,
      rating: 4.8,
      price: '89',
      image: 'bg-gradient-to-br from-cyan-600 to-blue-800',
      progress: 0,
      modules: 16,
    },
    {
      id: 'db-1',
      title: 'Database Design & Optimization',
      description: 'SQL optimization, indexing, and NoSQL databases in production.',
      level: 'Intermediate',
      duration: '7 weeks',
      students: 7100,
      rating: 4.7,
      price: '109',
      image: 'bg-gradient-to-br from-emerald-600 to-green-800',
      progress: 0,
      modules: 17,
    },
    {
      id: 'web-1',
      title: 'Full-Stack Development with Next.js',
      description: 'Build modern full-stack applications with Next.js and React.',
      level: 'Intermediate',
      duration: '9 weeks',
      students: 15400,
      rating: 4.9,
      price: '119',
      image: 'bg-gradient-to-br from-slate-700 to-slate-900',
      progress: 0,
      modules: 21,
    },
  ]

  const toggleSave = (id: string) => {
    setSavedCourses((prev) =>
      prev.includes(id) ? prev.filter((cid) => cid !== id) : [...prev, id]
    )
  }

  return (
    <motion.div
      className="max-w-6xl mx-auto space-y-6"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      <motion.div variants={itemVariants}>
        <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary mb-2">
          Course Recommendations
        </h1>
        <p className="text-muted-foreground">
          Personalized courses matched to your skill gaps and career goals
        </p>
      </motion.div>

      {/* Filter & Sort */}
      <motion.div
        className="flex flex-wrap gap-3 p-4 rounded-xl glass"
        variants={itemVariants}
      >
        {['All', 'Advanced', 'Intermediate', 'My Saved'].map((filter) => (
          <motion.button
            key={filter}
            className="px-4 py-2 rounded-lg smooth-transition"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <span className="text-sm font-medium">{filter}</span>
          </motion.button>
        ))}
      </motion.div>

      {/* Courses Grid */}
      <motion.div
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        variants={containerVariants}
      >
        {courses.map((course) => {
          const isSaved = savedCourses.includes(course.id)

          return (
            <motion.div
              key={course.id}
              className="premium-card flex flex-col overflow-hidden group"
              variants={itemVariants}
              whileHover={{ y: -8 }}
            >
              {/* Course Image */}
              <div className={`w-full h-40 ${course.image} rounded-xl mb-4 relative overflow-hidden`}>
                <motion.div
                  className="absolute inset-0 flex items-center justify-center"
                  whileHover={{ scale: 1.1 }}
                >
                  <motion.button
                    className="p-4 rounded-full bg-white/20 backdrop-blur-sm hover:bg-white/30 smooth-transition"
                    whileHover={{ scale: 1.2 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    <Play className="w-8 h-8 text-white fill-white" />
                  </motion.button>
                </motion.div>
              </div>

              {/* Content */}
              <div className="flex-1 space-y-3">
                {/* Title & Level */}
                <div>
                  <div className="flex items-start justify-between mb-2">
                    <span className={`text-xs px-2 py-1 rounded-full font-bold ${
                      course.level === 'Advanced'
                        ? 'bg-red-500/20 text-red-300'
                        : 'bg-yellow-500/20 text-yellow-300'
                    }`}>
                      {course.level}
                    </span>
                    <motion.button
                      onClick={() => toggleSave(course.id)}
                      className="p-2 rounded-lg hover:bg-white/10 smooth-transition"
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                    >
                      <Bookmark
                        className={`w-5 h-5 ${
                          isSaved ? 'fill-accent text-accent' : 'text-muted-foreground'
                        }`}
                      />
                    </motion.button>
                  </div>
                  <h3 className="font-bold text-foreground text-lg leading-tight">
                    {course.title}
                  </h3>
                </div>

                {/* Description */}
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {course.description}
                </p>

                {/* Stats */}
                <div className="flex flex-wrap gap-4 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Clock className="w-4 h-4" /> {course.duration}
                  </span>
                  <span className="flex items-center gap-1">
                    <Users className="w-4 h-4" /> {course.students.toLocaleString()}
                  </span>
                  <span className="flex items-center gap-1">
                    <Star className="w-4 h-4 fill-accent text-accent" /> {course.rating}
                  </span>
                </div>

                {/* Modules */}
                <div className="pt-2 border-t border-white/10">
                  <p className="text-xs text-muted-foreground mb-2">
                    {course.modules} modules included
                  </p>
                </div>
              </div>

              {/* CTA Button */}
              <motion.button
                className="w-full py-3 rounded-lg bg-gradient-to-r from-primary via-secondary to-accent text-primary-foreground font-bold smooth-transition mt-4 hover:shadow-lg hover:shadow-primary/50"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                Enroll Now • ${course.price}
              </motion.button>
            </motion.div>
          )
        })}
      </motion.div>

      {/* Why These Courses */}
      <motion.div
        className="premium-card gradient-teal-violet"
        variants={itemVariants}
      >
        <div className="flex items-center gap-3 mb-4">
          <BookOpen className="w-6 h-6 text-accent" />
          <h2 className="text-2xl font-bold text-foreground">Why These Courses?</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            {
              title: 'System Design is Critical',
              desc: 'You have a 35% gap here. Mastering this will directly impact your interview success.',
            },
            {
              title: 'Cloud Skills Are In-Demand',
              desc: '90% of top tech companies use cloud. AWS knowledge sets you apart.',
            },
            {
              title: 'DevOps Experience Required',
              desc: 'Modern development requires deployment knowledge. Kubernetes is essential.',
            },
            {
              title: 'Full-Stack Opportunities',
              desc: 'Next.js enables building complete applications. High-paying skill.',
            },
          ].map((reason, idx) => (
            <motion.div
              key={idx}
              className="p-4 rounded-lg bg-white/5 border border-white/10"
              whileHover={{ borderColor: 'rgba(0, 201, 167, 0.3)' }}
            >
              <p className="font-semibold text-foreground mb-2">{reason.title}</p>
              <p className="text-sm text-muted-foreground">{reason.desc}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </motion.div>
  )
}
